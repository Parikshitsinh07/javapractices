package com.springcore.javaconfig;

public class Samosa {
	public void display() {
		System.out.println("Hello from the samosa");
	}
}
