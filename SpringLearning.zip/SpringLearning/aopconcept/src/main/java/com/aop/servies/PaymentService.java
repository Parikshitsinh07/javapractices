package com.aop.servies;

public interface PaymentService {
	public void makePayment();

}
