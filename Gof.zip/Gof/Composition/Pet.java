class Pet {
     String name;
     String species;

    public Pet(String name, String species) {
        this.name = name;
        this.species = species;
    }
}