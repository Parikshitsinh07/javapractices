class Department {
    String name;

    // Constructor
    public Department(String name) {
        this.name = name;
    }
}