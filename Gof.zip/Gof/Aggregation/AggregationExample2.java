public class AggregationExample2 {
    public static void main(String[] args) {
       
        Smartphone phone = new Smartphone("Samsung", "Galaxy S21");

        Person person = new Person("Parikshit", 25, phone);

      
        person.displayPerson();
    }
}
