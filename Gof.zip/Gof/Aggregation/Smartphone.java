class Smartphone {
    String brand;
    String model;

    // Constructor
    public Smartphone(String brand, String model) {
        this.brand = brand;
        this.model = model;
    }
}