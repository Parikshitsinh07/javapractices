package com.razorpay;

import org.json.JSONObject;

public class Payment extends Entity {

  public Payment(JSONObject jsonObject) {
    super(jsonObject);
  }
}
