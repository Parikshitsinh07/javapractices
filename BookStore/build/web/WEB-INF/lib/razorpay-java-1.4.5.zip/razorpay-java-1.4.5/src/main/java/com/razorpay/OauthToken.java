package com.razorpay;

import org.json.JSONObject;

public class OauthToken extends Entity {

    public OauthToken(JSONObject jsonObject) {
        super(jsonObject);
    }
}