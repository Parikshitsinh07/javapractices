package com.razorpay;

import org.json.JSONObject;

public class Invoice extends Entity {

  public Invoice(JSONObject jsonObject) {
    super(jsonObject);
  }
}
