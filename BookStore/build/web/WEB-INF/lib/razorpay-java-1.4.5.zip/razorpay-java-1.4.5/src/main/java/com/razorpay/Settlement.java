package com.razorpay;

import org.json.JSONObject;

public class Settlement extends Entity {

    public Settlement(JSONObject jsonObject) {
        super(jsonObject);
    }
}