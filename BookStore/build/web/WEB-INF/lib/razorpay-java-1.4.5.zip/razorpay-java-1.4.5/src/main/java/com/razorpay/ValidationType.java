package com.razorpay;

public enum ValidationType {
    NON_NULL,
    NON_EMPTY_STRING,
    URL,
    ID,
    MODE,
    TOKEN_GRANT
}
