package com.razorpay;

import org.json.JSONObject;

public class Card extends Entity {

  public Card(JSONObject jsonObject) {
    super(jsonObject);
  }
}
