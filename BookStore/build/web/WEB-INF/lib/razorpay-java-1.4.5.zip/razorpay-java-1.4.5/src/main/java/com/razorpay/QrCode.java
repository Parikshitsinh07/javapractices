package com.razorpay;

import org.json.JSONObject;

public class QrCode extends Entity {

    public QrCode(JSONObject jsonObject) {
        super(jsonObject);
    }
}
