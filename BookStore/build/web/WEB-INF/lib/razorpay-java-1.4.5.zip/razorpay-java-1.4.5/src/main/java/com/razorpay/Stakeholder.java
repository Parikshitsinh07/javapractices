package com.razorpay;

import org.json.JSONObject;

public class Stakeholder extends Entity {

    public Stakeholder(JSONObject jsonObject) {
        super(jsonObject);
    }
}
