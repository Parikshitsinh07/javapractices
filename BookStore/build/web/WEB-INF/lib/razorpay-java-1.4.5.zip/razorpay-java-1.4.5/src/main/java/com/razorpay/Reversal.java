package com.razorpay;

import org.json.JSONObject;

public class Reversal extends Entity {

  public Reversal(JSONObject jsonObject) {
    super(jsonObject);
  }
}
