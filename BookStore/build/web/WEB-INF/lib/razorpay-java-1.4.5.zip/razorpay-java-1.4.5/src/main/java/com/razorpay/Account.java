package com.razorpay;

import org.json.JSONObject;

public class Account extends Entity {

    public Account(JSONObject jsonObject) {
        super(jsonObject);
    }
}
