package com.razorpay;

import org.json.JSONObject;

public class Iin extends Entity {

    public Iin(JSONObject jsonObject) {
        super(jsonObject);
    }
}