package com.razorpay;

import org.json.JSONObject;

public class Customer extends Entity {

  public Customer(JSONObject jsonObject) {
    super(jsonObject);
  }
}
