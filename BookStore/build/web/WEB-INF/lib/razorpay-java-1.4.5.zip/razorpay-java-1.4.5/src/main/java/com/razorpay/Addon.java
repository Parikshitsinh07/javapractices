package com.razorpay;

import org.json.JSONObject;

public class Addon extends Entity {

  public Addon(JSONObject jsonObject) {
    super(jsonObject);
  }
}
