package com.razorpay;

import org.json.JSONObject;

public class Item extends Entity {

  public Item(JSONObject jsonObject) {
    super(jsonObject);
  }
}